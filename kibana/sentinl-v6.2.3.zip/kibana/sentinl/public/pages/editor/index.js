/* global angular */
import Editor from './editor.controller';

export default angular.module('apps/sentinl.editorPage', [])
.controller('EditorController', Editor);
