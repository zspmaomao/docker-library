export default {
  description: 'Report/Alarm application',
  reports: {
    title: 'Reports',
  },
  watchers: {
    title: 'Watchers',
  },
  alarms: {
    title: 'Alarms',
  },
  editor: {
    title: 'Editor',
  },
  about: {
    title: 'About',
  },
};
