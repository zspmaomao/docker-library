import SavedObjects from './saved_objects';
export default SavedObjects;
