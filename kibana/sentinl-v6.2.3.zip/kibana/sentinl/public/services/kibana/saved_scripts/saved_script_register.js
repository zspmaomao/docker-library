import './saved_scripts';

export default function savedSearchObjectFn(savedScriptsKibana) {
  return savedScriptsKibana;
}
