export default function savedScriptsRegister(savedScripts) {
  return savedScripts;
}
