/*global angular*/
import reportAction from './report_action';
export default angular.module('apps/sentinl.reportAction', []).directive(reportAction.name, reportAction);
